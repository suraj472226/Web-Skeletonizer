import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './register.css'; // Import the specific CSS file

const Register = () => {
    const [userName, setUserName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error] = useState('');

    const handleSubmit = async (event) => {
    event.preventDefault();
    console.log('Registering:', { userName, email, password });
    
    try {
        const response = await fetch('http://localhost:5000/api/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ userName, email, password }),
        });

        const result = await response.json();

        if (response.ok) {
            // Registration successful
            document.getElementById('message').textContent = result.message;
            setUserName('');
            setEmail('');
            setPassword('');
        } else {
            // Handle error messages from the server
            document.getElementById('message').textContent = result.message;
        }
    } catch (error) {
        console.error('Error during registration:', error);
        document.getElementById('message').textContent = 'An error occurred during registration.';
    }
};


    return (
        <div className="register-container">
            <p id="message"></p>
            <h2 className="register-title">Register</h2>
            <form className="register-form" onSubmit={handleSubmit}>
                <div className="form-group">
                    <label>Username:</label>
                    <input
                        type="text"
                        className="form-input"
                        value={userName}
                        onChange={(e) => setUserName(e.target.value)}
                        required
                    />
                </div>
                <div className="form-group">
                    <label>Email:</label>
                    <input
                        type="email"
                        className="form-input"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    />
                </div>
                <div className="form-group">
                    <label>Password:</label>
                    <input
                        type="password"
                        className="form-input"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                </div>
                <button type="submit" className="register-button">Register</button>
                {error && <p className="error-message">{error}</p>}
            </form>
            <p>
                Already have an account? <Link to="/login">Login here</Link>
            </p>
        </div>
    );
};

export default Register;
