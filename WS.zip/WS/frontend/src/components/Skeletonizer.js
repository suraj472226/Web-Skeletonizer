// Skeletonizer.js
import React, { useState } from 'react';
import axios from 'axios';
import './skeletonizer.css'; // Import the specific CSS file for Skeletonizer

const Skeletonizer = () => {
    const [url, setUrl] = useState('');
    const [skeleton, setSkeleton] = useState('');
    const [error, setError] = useState(''); // State to manage error messages

    const handleSubmit = async (e) => {
        e.preventDefault();
        const fullUrl = url.startsWith('http://') || url.startsWith('https://') ? url : `https://${url}`;
        console.log("Submitting URL:", fullUrl); // Log the final URL
        try {
            const response = await axios.post('http://localhost:5000/skeletonize', { url: fullUrl });
            console.log("Response from server:", response.data); // Log the response
            setSkeleton(response.data.skeleton);
            setError(''); // Clear any previous errors
        } catch (error) {
            console.error("There was an error!", error);
            setError('Failed to generate skeleton. Please check the URL and try again.');
        }
    };

    return (
        <div className="skeletonizer-container"> {/* Add a unique class name */}
            <h1>Web Skeletonizer</h1>
            <form onSubmit={handleSubmit}>
                <input
                    type="text"
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    placeholder="Enter website URL"
                    required
                />
                <button type="submit">Generate Skeleton</button>
            </form>
            {error && <p className="error-message">{error}</p>} {/* Use a class for error message */}
            <div className="output-container"> {/* Wrap the output in this div */}
            <pre>{skeleton}</pre>
        </div>
        </div>
    );
};

export default Skeletonizer;
