import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './savedOutputs.css';

const SavedOutputs = () => {
    const [savedSkeletons, setSavedSkeletons] = useState([]);
    const [selectedSkeleton, setSelectedSkeleton] = useState(null); // State to hold the selected skeleton
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchSavedSkeletons = async () => {
            try {
                const response = await axios.get('http://localhost:5000/api/saved-skeletons');
                setSavedSkeletons(response.data);
            } catch (error) {
                console.error("There was an error fetching the saved skeletons!", error);
                setError('Failed to fetch saved skeletons. Please try again later.');
            }
        };

        fetchSavedSkeletons();
    }, []);

    const handleSkeletonSelect = async (url) => {
        try {
            const filename = url.replace('http://', '').replace('https://', '').replace('/', '_').replace(':', '-') + '.txt'; // Ensure colon is replaced
            const response = await axios.get(`http://localhost:5000/api/skeletons/${filename}`); // New endpoint to get the skeleton
            setSelectedSkeleton(response.data.skeleton);
        } catch (error) {
            console.error("There was an error fetching the skeleton!", error);
            setError('Failed to fetch skeleton. Please try again later.');
        }
    };
    

    return (
        <div className="saved-outputs-container"> 
        <h2>Saved Outputs</h2>
        {error && <p className="error-message">{error}</p>}
        {savedSkeletons.length === 0 ? (
            <p className="no-skeletons">No saved skeletons found.</p> 
        ) : (
            <ul className="skeleton-list"> {/* Use a class for the list */}
                {savedSkeletons.map((skeleton, index) => (
                    <li key={index} className="skeleton-item"> 
                        <button onClick={() => handleSkeletonSelect(skeleton.url)}>{skeleton.url}</button>
                    </li>
                ))}
            </ul>
        )}
        {selectedSkeleton && (
            <div className="selected-skeleton"> 
                <h3>Skeleton Content:</h3>
                <pre>{selectedSkeleton}</pre>
            </div>

        )}
        </div>
    );
};

export default SavedOutputs;
