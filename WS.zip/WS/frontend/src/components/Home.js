// Home.js
import React from 'react';
import { Link } from 'react-router-dom';
import './Home.css';

const Home = () => {
    return (
        <div>
            <h1>Welcome to the Web Skeletonizer</h1>
            <p>Your go-to tool for generating HTML skeletons!</p>
            <Link to="/login">Login</Link>
            <Link to="/register">Register</Link>
        </div>
    );
};

export default Home;
