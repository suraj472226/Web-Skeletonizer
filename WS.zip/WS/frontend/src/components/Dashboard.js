// Dashboard.js
import React, { useEffect, useState } from 'react';
import { Link, Routes, Route } from 'react-router-dom';
import Profile from './Profile';
import Skeletonizer from './Skeletonizer';
import SavedOutputs from './SavedOutputs';
import './dashboard.css'; // Import the specific CSS file for Dashboard

const Dashboard = () => {
    const [user, setUser] = useState(null);
    const [savedSkeletons, setSavedSkeletons] = useState([]); // Initialize savedSkeletons

    useEffect(() => {
        const storedUser = JSON.parse(sessionStorage.getItem('user'));
        if (storedUser) {
            setUser(storedUser);
        } else {
            // Redirect to login if no user is found
            window.location.href = '/login';
        }
    }, []);

    if (!user) {
        return <p>Loading...</p>; // Handle loading state
    }

    return (
        <div className="dashboard-container"> {/* Add a unique class name */}
            <h1>Welcome, {user.userName ? user.userName : 'User'}!</h1>
            <nav>
                <Link to="/dashboard/profile">Profile</Link>
                <Link to="/dashboard/skeletonizer">Skeletonizer</Link>
                <Link to="/dashboard/saved-outputs">Saved Outputs</Link>
            </nav>

            <Routes>
                <Route path="profile" element={<Profile user={user} />} />
                <Route path="skeletonizer" element={<Skeletonizer />} />
                <Route path="saved-outputs" element={<SavedOutputs savedSkeletons={savedSkeletons} />} />
                <Route path="*" element={<p>404 Not Found</p>} /> {/* Fallback route */}
            </Routes>
        </div>
    );
};

export default Dashboard;
