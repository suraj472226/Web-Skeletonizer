// Profile.js
import React from 'react';
import './profile.css'; // Import the specific CSS file for Profile

const Profile = ({ user }) => {
    return (
        <div className="profile-container"> {/* Add a unique class name */}
            <h2>User Profile</h2>
            <p>Username: {user.userName}</p>
            <p>Email: {user.email}</p>
            {/* Add more fields and edit functionality as needed */}
        </div>
    );
};

export default Profile;
